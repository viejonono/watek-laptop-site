import Head from 'next/head'

export default function Home() {
  const laptops = [
    {
      modelo: "Dell Latitude 5411",
      procesador: "Core i5-10400H",
      pantalla: "14\"",
      precio: 175000,
      stock: 36,
    },
    {
      modelo: "HP EliteBook 830 G7",
      procesador: "Core i7-10610U",
      pantalla: "13.3\"",
      precio: 235000,
      stock: 7,
    },
    {
      modelo: "Acer Chromebook Spin 511",
      procesador: "Celeron N4020",
      pantalla: "11.6\"",
      precio: 59000,
      stock: 0,
    },
  ];

  return (
    <>
      <Head>
        <title>Catálogo Watek Inc.</title>
      </Head>
      <main className="p-4 max-w-5xl mx-auto">
        <h1 className="text-2xl font-bold mb-4">Catálogo Watek Inc.</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {laptops.map((item, index) => (
            <div key={index} className="border p-4 shadow rounded-lg">
              <img src="/placeholder.png" alt="Laptop" className="mb-2 w-full h-40 object-cover" />
              <h2 className="font-bold text-lg">{item.modelo}</h2>
              <p>{item.pantalla} - {item.procesador}</p>
              <p>₡{item.precio.toLocaleString('es-CR')}</p>
              <p className={item.stock > 0 ? "text-green-600" : "text-red-600"}>
                {item.stock > 0 ? "Disponible" : "Agotado"}
              </p>
            </div>
          ))}
        </div>
      </main>
    </>
  );
}
